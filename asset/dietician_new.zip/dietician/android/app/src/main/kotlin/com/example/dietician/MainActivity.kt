package com.example.dietician

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
